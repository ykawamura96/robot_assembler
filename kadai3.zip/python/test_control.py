#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
import actionlib
from math import pi
import subprocess
import numpy as np
from std_msgs.msg import Float64
from gazebo_msgs.msg import LinkStates
from sensor_msgs.msg import Imu
from control_msgs.msg import FollowJointTrajectoryAction, FollowJointTrajectoryGoal
from trajectory_msgs.msg import JointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from tf.transformations import euler_from_quaternion, quaternion_from_euler


class Test(object):
    
    def __init__(self):
        rospy.init_node('test', anonymous=True)
        self.command_topics = ['/wheeled_robot/joint{}_position_controller/command'.format(i) for i in range (14)]
        self.command_pub = [rospy.Publisher(self.command_topics[i], Float64, queue_size=10) for i in range(14)]
        self.subscribe_topic = '/imu_sensor'
        self.t = 0
        (self.r_wheel, self.l_wheel) = (0, 0)
        rospy.Subscriber(self.subscribe_topic, Imu, self.callback)

    def callback(self, imu_data):
        # from IPython import embed; embed()
        q = imu_data.orientation
        (roll, pitch, yaw) = euler_from_quaternion([q.x, q.y, q.z, q.w])
        self.pitch = pitch
        # print ("angle: {}".format(pitch))
        self.t = self.t + 1
        self.r_wheel = pi * np.sin(self.t/100.0)
        self.l_wheel = pi * np.sin(self.t/100.0)
        self._command_angle_to_wheels(self.r_wheel, self.l_wheel)

    def _command_angle_to_wheels(self, r, l):
        self.command_pub[6].publish(r)
        self.command_pub[13].publish(l)
        print("right: {} \t left: {}\n".format(r, l))
        
    def run(self):
        rospy.spin()

def main():
    test = Test()
    test.run()

if __name__ == "__main__":
    main()
