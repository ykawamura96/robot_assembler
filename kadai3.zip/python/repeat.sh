while true;
do
    ./test_pid.py
done
