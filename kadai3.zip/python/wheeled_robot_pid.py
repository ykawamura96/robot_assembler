#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
import actionlib
from math import pi
import subprocess
import numpy
from gazebo_msgs.msg import LinkStates
from std_msgs.msg import Float64
from sensor_msgs.msg import Imu
from tf.transformations import euler_from_quaternion, quaternion_from_euler

POSITION_CONTROL_MODE = True
EFFORT_CONTROL_MODE = False
def rad2deg(rad):
    return rad / pi / 2 * 360

class PIDController(object):

    def __init__(self):
        rospy.init_node('pid', anonymous=True)
        if POSITION_CONTROL_MODE:
            self.KP = 0.80
            self.KD = 5.20
            self.KI = 0.0
        if EFFORT_CONTROL_MODE:
            self.KP = 0.05
            self.KD = 0.04
            self.KI = 0.0
            
        self.idiff = 0
        self.pitch = 0
        self.last_pitch = 0
        self.r_wheel = 0
        self.l_wheel = 0
        rospy.Subscriber('/imu_sensor', Imu, self.callback)
        self.command_topics = ['/wheeled_robot/joint{}_position_controller/command'.format(i) for i in range (14)]
        self.command_pub = [rospy.Publisher(self.command_topics[i], Float64, queue_size=10) for i in range(14)]
        self.t = 0

    def run(self):
        rospy.spin()

    def callback(self, data):
        q = [data.orientation.x, data.orientation.y, data.orientation.z, data.orientation.w]
        (roll, pitch, yaw) = euler_from_quaternion(q)
        self.pitch = pitch
        print ("current angle: {}".format(pitch))
        self.r_wheel, self.l_wheel = self._calc_target()
        self._command_angle_to_wheels(self.r_wheel, self.l_wheel)
        rospy.loginfo("wheel target : {}".format(self.r_wheel))

    def _calc_target(self):
        target_angle = -0.00
        diff = target_angle - self.pitch
        ddiff = self.last_pitch - self.pitch
        idff = self.idiff
        target_diff  =  self.KP * diff + self.KD * ddiff + self.KI * self.idiff
        self.idiff += diff
        self.last_pitch = self.pitch
        print("target_diff = {}".format(target_diff))
        if diff > 1.4 or diff < -1.4:
            return self.r_wheel, self.l_wheel
        else:
            return self.r_wheel + target_diff, self.l_wheel - target_diff

    def _command_angle_to_wheels(self, r, l):
        self.command_pub[6].publish(r)
        self.command_pub[13].publish(l)
        print("right: {} \t left: {}\n".format(r, l))
        
def main():
    subprocess.call(["rosservice", "call", "/gazebo/reset_world"])
    PC = PIDController()
    PC.run()

if __name__ == '__main__':
    main()

    
